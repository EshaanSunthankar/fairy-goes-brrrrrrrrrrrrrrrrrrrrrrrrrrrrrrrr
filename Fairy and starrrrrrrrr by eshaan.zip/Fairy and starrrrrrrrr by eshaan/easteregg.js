//if you have found me congrats u have officially found my easter egg this is not a functin but it wll tell you thught of the day



//Thought of the day : u can see it in thought.png in directory since i didn't wanted to mess up :D















//reply with this code : 1209